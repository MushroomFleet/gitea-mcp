# Gitea MCP Server API Documentation

## Overview

The Gitea MCP Server provides two primary tools for interacting with self-hosted Gitea instances through the Model Context Protocol (MCP).

## Authentication

All API calls require authentication via personal access tokens configured in the environment variables. Each Gitea instance must have its own token with appropriate permissions.

### Required Permissions

- `repo`: Full repository access
- `write:repository`: Create repositories
- `read:user`: Read user information

## Tools

### create_repository

Creates a new repository on the specified Gitea instance.

**Tool Name:** `create_repository`

**Description:** Create a new repository on Gitea instance

**Parameters:**

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `instanceId` | string | ✓ | - | Gitea instance identifier from configuration |
| `name` | string | ✓ | - | Repository name (must be valid Git repository name) |
| `description` | string | ✗ | "" | Repository description |
| `private` | boolean | ✗ | true | Whether the repository should be private |
| `autoInit` | boolean | ✗ | true | Initialize repository with README.md |
| `defaultBranch` | string | ✗ | "main" | Default branch name |

**Example Request:**

```json
{
  "tool": "create_repository",
  "arguments": {
    "instanceId": "main",
    "name": "my-awesome-project",
    "description": "An awesome project for demonstrating Gitea MCP",
    "private": true,
    "autoInit": true,
    "defaultBranch": "main"
  }
}
```

**Example Response:**

```json
{
  "content": [
    {
      "type": "text",
      "text": "{\n  \"success\": true,\n  \"repository\": {\n    \"id\": 123,\n    \"name\": \"my-awesome-project\",\n    \"fullName\": \"username/my-awesome-project\",\n    \"url\": \"https://gitea.example.com/username/my-awesome-project\",\n    \"cloneUrl\": \"https://gitea.example.com/username/my-awesome-project.git\",\n    \"sshUrl\": \"git@gitea.example.com:username/my-awesome-project.git\",\n    \"private\": true,\n    \"createdAt\": \"2023-12-01T10:00:00Z\"\n  }\n}"
    }
  ]
}
```

**Error Responses:**

- `VALIDATION_ERROR`: Invalid parameters provided
- `NOT_FOUND`: Gitea instance not found
- `UNAUTHORIZED`: Authentication failed
- `EXTERNAL_API_ERROR`: Repository creation failed

### upload_files

Uploads multiple files to a Gitea repository while preserving directory structure.

**Tool Name:** `upload_files`

**Description:** Upload files and folders to Gitea repository while preserving directory structure

**Parameters:**

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `instanceId` | string | ✓ | - | Gitea instance identifier from configuration |
| `owner` | string | ✓ | - | Repository owner username |
| `repository` | string | ✓ | - | Repository name |
| `files` | array | ✓ | - | Array of file objects to upload |
| `files[].path` | string | ✓ | - | File path within repository (forward slashes) |
| `files[].content` | string | ✓ | - | File content (UTF-8 text) |
| `message` | string | ✓ | - | Commit message for the upload |
| `branch` | string | ✗ | "main" | Target branch name |
| `batchSize` | number | ✗ | 10 | Number of files to upload per batch |

**File Path Rules:**

- Use forward slashes (`/`) for directory separators
- No leading slash (relative paths only)
- No `..` sequences (security restriction)
- No empty directory names

**Example Request:**

```json
{
  "tool": "upload_files",
  "arguments": {
    "instanceId": "main",
    "owner": "username",
    "repository": "my-awesome-project",
    "files": [
      {
        "path": "README.md",
        "content": "# My Awesome Project\n\nThis is an awesome project!"
      },
      {
        "path": "src/index.js",
        "content": "console.log('Hello, World!');"
      },
      {
        "path": "src/utils/helper.js",
        "content": "export function greet(name) {\n  return `Hello, ${name}!`;\n}"
      },
      {
        "path": "package.json",
        "content": "{\n  \"name\": \"my-awesome-project\",\n  \"version\": \"1.0.0\"\n}"
      }
    ],
    "message": "Initial project setup with source files",
    "branch": "main",
    "batchSize": 5
  }
}
```

**Example Response:**

```json
{
  "content": [
    {
      "type": "text", 
      "text": "{\n  \"success\": true,\n  \"summary\": {\n    \"totalFiles\": 4,\n    \"uploaded\": 4,\n    \"failed\": 0\n  },\n  \"details\": {\n    \"repository\": \"username/my-awesome-project\",\n    \"branch\": \"main\",\n    \"commitMessage\": \"Initial project setup with source files\"\n  }\n}"
    }
  ]
}
```

**Partial Failure Response:**

```json
{
  "content": [
    {
      "type": "text",
      "text": "{\n  \"success\": false,\n  \"summary\": {\n    \"totalFiles\": 4,\n    \"uploaded\": 3,\n    \"failed\": 1\n  },\n  \"details\": {\n    \"failures\": [\n      \"File 'src/duplicate.js' already exists\"\n    ],\n    \"repository\": \"username/my-awesome-project\",\n    \"branch\": \"main\",\n    \"commitMessage\": \"Initial project setup with source files\"\n  }\n}"
    }
  ]
}
```

**Error Responses:**

- `VALIDATION_ERROR`: Invalid parameters or file paths
- `NOT_FOUND`: Gitea instance or repository not found
- `UNAUTHORIZED`: Authentication failed or insufficient permissions
- `EXTERNAL_API_ERROR`: File upload failed

## Rate Limiting

The server implements rate limiting per Gitea instance to respect API limits:

- Default: 100 requests per minute per instance
- Configurable via `rateLimit` in instance configuration
- Automatic retry with exponential backoff on rate limit errors

## Batch Processing

File uploads are processed in batches to optimize performance and respect rate limits:

- Default batch size: 10 files
- Configurable per request via `batchSize` parameter
- 1-second delay between batches
- Each batch processed concurrently within the batch

## Error Handling

All tools implement comprehensive error handling:

### Error Codes

- `VALIDATION_ERROR`: Invalid input parameters
- `NOT_FOUND`: Resource not found (instance, repository, etc.)
- `UNAUTHORIZED`: Authentication or permission issues
- `EXTERNAL_API_ERROR`: Gitea API errors
- `RATE_LIMITED`: Rate limit exceeded
- `INTERNAL_ERROR`: Server internal errors

### Error Response Format

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": {
      "additional": "context information"
    }
  }
}
```

## Configuration Management

### Instance Configuration

Each Gitea instance requires configuration in the `GITEA_INSTANCES` environment variable:

```json
[
  {
    "id": "production",
    "name": "Production Gitea",
    "baseUrl": "https://gitea.company.com",
    "token": "your-production-token",
    "timeout": 30000,
    "rateLimit": {
      "requests": 100,
      "windowMs": 60000
    }
  }
]
```

### Instance Selection

Use the `instanceId` parameter to specify which configured Gitea instance to use for each operation. The instance ID must match one configured in the environment.

## Usage Examples

### Creating a Repository and Uploading Files

1. **Create Repository:**

```json
{
  "tool": "create_repository",
  "arguments": {
    "instanceId": "main",
    "name": "web-app",
    "description": "A modern web application",
    "private": false
  }
}
```

2. **Upload Project Files:**

```json
{
  "tool": "upload_files", 
  "arguments": {
    "instanceId": "main",
    "owner": "myusername",
    "repository": "web-app",
    "files": [
      {
        "path": "index.html",
        "content": "<!DOCTYPE html>\n<html>\n<head>\n  <title>My Web App</title>\n</head>\n<body>\n  <h1>Welcome!</h1>\n</body>\n</html>"
      },
      {
        "path": "css/style.css", 
        "content": "body {\n  font-family: Arial, sans-serif;\n  margin: 0;\n  padding: 20px;\n}"
      },
      {
        "path": "js/app.js",
        "content": "document.addEventListener('DOMContentLoaded', function() {\n  console.log('Web app loaded!');\n});"
      }
    ],
    "message": "Initial web app structure"
  }
}
```

### Working with Multiple Instances

```json
{
  "tool": "create_repository",
  "arguments": {
    "instanceId": "development",
    "name": "test-repo",
    "description": "Development testing repository"
  }
}
```

Then upload to production:

```json
{
  "tool": "upload_files",
  "arguments": {
    "instanceId": "production", 
    "owner": "myusername",
    "repository": "live-repo",
    "files": [...],
    "message": "Deploy to production"
  }
}
```

## Security Considerations

### Token Security

- Store tokens securely in environment variables
- Use minimal required permissions
- Rotate tokens regularly
- Never log or expose tokens in responses

### Input Validation

- All file paths are validated for security
- Path traversal attempts (`../`) are blocked
- File content is validated as UTF-8 text
- Repository and user names are validated

### Rate Limiting

- Respect Gitea instance rate limits
- Implement exponential backoff on failures
- Use appropriate batch sizes for bulk operations

## Monitoring and Logging

### Log Levels

- `debug`: Detailed operational information
- `info`: General operational events  
- `warn`: Warning conditions
- `error`: Error conditions

### Metrics

The server tracks these metrics:

- Tool execution counts
- Success/failure rates
- Response times
- Rate limit hits
- API errors by type

### Health Checks

Monitor server health via:

- Process health (main process running)
- Configuration validity
- Gitea instance connectivity
- Memory and CPU usage

## Troubleshooting

### Common Issues

**"Gitea instance 'xyz' not found"**
- Verify `instanceId` matches configuration
- Check `GITEA_INSTANCES` environment variable

**"Authentication failed"**
- Verify access token is correct
- Check token permissions
- Ensure token hasn't expired

**"Repository not found"**
- Verify repository exists
- Check owner username is correct
- Ensure you have access to the repository

**"File upload failed"**
- Check file paths are valid
- Verify repository write permissions
- Ensure files don't already exist (if creating new files)

### Debug Mode

Enable debug logging for detailed troubleshooting:

```bash
LOG_LEVEL=debug npm start
```

This provides detailed information about:
- API requests and responses
- Rate limiting decisions
- Retry attempts
- Configuration loading
- Error details
