#!/usr/bin/env node

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ErrorCode,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';
import { setupErrorHandling } from "./utils/error-handling.js";
import { logger } from "./utils/logging.js";
import { validateConfig } from "./config/validation.js";
import { loadConfig } from './config/index.js';

class GiteaMcpServer {
  private server: Server;

  constructor() {
    this.server = new Server({
      name: "gitea-mcp",
      version: "1.0.0"
    }, {
      capabilities: {
        tools: {},
      },
    });

    this.setupToolHandlers();
    
    // Error handling
    this.server.onerror = (error) => {
      logger.error('[MCP Error]', error);
    };
  }

  private setupToolHandlers() {
    // Register available tools
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: 'create_repository',
          description: 'Create a new repository on Gitea instance',
          inputSchema: {
            type: 'object',
            properties: {
              instanceId: {
                type: 'string',
                description: 'Gitea instance identifier'
              },
              name: {
                type: 'string',
                description: 'Repository name'
              },
              description: {
                type: 'string',
                description: 'Repository description'
              },
              private: {
                type: 'boolean',
                description: 'Make repository private'
              },
              autoInit: {
                type: 'boolean',
                description: 'Initialize with README'
              },
              defaultBranch: {
                type: 'string',
                description: 'Default branch name'
              }
            },
            required: ['instanceId', 'name']
          }
        },
        {
          name: 'upload_files',
          description: 'Upload files to Gitea repository',
          inputSchema: {
            type: 'object',
            properties: {
              instanceId: {
                type: 'string',
                description: 'Gitea instance identifier'
              },
              owner: {
                type: 'string',
                description: 'Repository owner'
              },
              repository: {
                type: 'string',
                description: 'Repository name'
              },
              files: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    path: {
                      type: 'string',
                      description: 'File path in repository'
                    },
                    content: {
                      type: 'string',
                      description: 'File content (text or base64)'
                    }
                  },
                  required: ['path', 'content']
                },
                description: 'Array of files to upload'
              },
              message: {
                type: 'string',
                description: 'Commit message'
              },
              branch: {
                type: 'string',
                description: 'Target branch'
              }
            },
            required: ['instanceId', 'owner', 'repository', 'files', 'message']
          }
        }
      ]
    }));

    // Handle tool calls
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      if (name === 'create_repository') {
        return await this.handleCreateRepository(args);
      } else if (name === 'upload_files') {
        return await this.handleUploadFiles(args);
      } else {
        throw new McpError(
          ErrorCode.MethodNotFound,
          `Unknown tool: ${name}`
        );
      }
    });
  }

  private async handleCreateRepository(args: any) {
    try {
      logger.debug('Creating repository', { args });

      // Get configuration
      const config = loadConfig();
      const instance = config.gitea.instances.find(inst => inst.id === args.instanceId);
      
      if (!instance) {
        throw new McpError(ErrorCode.InvalidParams, `Gitea instance '${args.instanceId}' not found`);
      }

      // Prepare request body
      const requestBody = {
        name: args.name,
        description: args.description || '',
        private: args.private !== undefined ? args.private : false,
        auto_init: args.autoInit !== undefined ? args.autoInit : true,
        default_branch: args.defaultBranch || 'main'
      };

      // Make API call
      const response = await fetch(`${instance.baseUrl}/api/v1/user/repos`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `token ${instance.token}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorText = await response.text();
        return {
          content: [{
            type: 'text',
            text: `Failed to create repository: ${response.status} ${response.statusText} - ${errorText}`
          }],
          isError: true
        };
      }

      const repository = await response.json();

      logger.info('Repository created successfully', {
        instanceId: args.instanceId,
        repository: repository.name,
        id: repository.id
      });

      return {
        content: [{
          type: 'text',
          text: JSON.stringify({
            success: true,
            repository: {
              id: repository.id,
              name: repository.name,
              fullName: repository.full_name,
              url: repository.html_url,
              cloneUrl: repository.clone_url,
              private: repository.private,
              createdAt: repository.created_at
            }
          }, null, 2)
        }]
      };

    } catch (error) {
      logger.error('Failed to create repository', { error, args });
      return {
        content: [{
          type: 'text',
          text: `Error creating repository: ${error instanceof Error ? error.message : 'Unknown error'}`
        }],
        isError: true
      };
    }
  }

  private async handleUploadFiles(args: any) {
    try {
      logger.debug('Uploading files', { args });

      // Get configuration
      const config = loadConfig();
      const instance = config.gitea.instances.find(inst => inst.id === args.instanceId);
      
      if (!instance) {
        throw new McpError(ErrorCode.InvalidParams, `Gitea instance '${args.instanceId}' not found`);
      }

      const results = [];
      const branch = args.branch || 'main';

      // Upload each file
      for (const file of args.files) {
        try {
          // Convert content to base64
          const base64Content = Buffer.from(file.content, 'utf8').toString('base64');
          
          const requestBody = {
            content: base64Content,
            message: args.message,
            branch: branch
          };

          const response = await fetch(`${instance.baseUrl}/api/v1/repos/${args.owner}/${args.repository}/contents/${file.path}`, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authorization': `token ${instance.token}`
            },
            body: JSON.stringify(requestBody)
          });

          if (response.ok) {
            results.push({ file: file.path, status: 'success' });
          } else {
            const errorText = await response.text();
            results.push({ file: file.path, status: 'failed', error: `${response.status}: ${errorText}` });
          }
        } catch (error) {
          results.push({ file: file.path, status: 'failed', error: error instanceof Error ? error.message : 'Unknown error' });
        }
      }

      const successCount = results.filter(r => r.status === 'success').length;
      const failureCount = results.filter(r => r.status === 'failed').length;

      logger.info('File upload completed', {
        instanceId: args.instanceId,
        repository: `${args.owner}/${args.repository}`,
        successCount,
        failureCount
      });

      return {
        content: [{
          type: 'text',
          text: JSON.stringify({
            success: failureCount === 0,
            summary: {
              totalFiles: args.files.length,
              uploaded: successCount,
              failed: failureCount
            },
            results: results
          }, null, 2)
        }]
      };

    } catch (error) {
      logger.error('Failed to upload files', { error, args });
      return {
        content: [{
          type: 'text',
          text: `Error uploading files: ${error instanceof Error ? error.message : 'Unknown error'}`
        }],
        isError: true
      };
    }
  }

  async run() {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    logger.info('Gitea MCP Server running on stdio');
  }
}

async function main() {
  try {
    // Validate configuration on startup
    const config = await validateConfig();
    
    // Set up global error handling
    setupErrorHandling();

    const server = new GiteaMcpServer();
    await server.run();

    logger.info("Gitea MCP Server started successfully", {
      version: "1.0.0",
      giteaInstances: config.gitea.instances.length
    });

  } catch (error) {
    logger.error("Failed to start Gitea MCP server", { error });
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('Received SIGTERM, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('Received SIGINT, shutting down gracefully');
  process.exit(0);
});

main().catch((error) => {
  logger.error("Unhandled error in main", { error });
  process.exit(1);
});
