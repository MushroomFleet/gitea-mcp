// This file is no longer used - tools are now registered directly in src/index.ts
export function initializeTools() {
  // No longer needed - functionality moved to src/index.ts
}
