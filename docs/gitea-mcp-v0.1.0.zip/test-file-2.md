# Second Test File

This is another test file created for uploading to the Gitea repository using the MCP tool.

## Purpose

- Testing the MCP upload_files tool
- Demonstrating file upload capabilities
- Verifying MCP functionality
