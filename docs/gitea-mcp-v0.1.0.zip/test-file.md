# Test File

This is a test file created for uploading to the Gitea repository.

## Features

- Simple Markdown formatting
- Created using the gitea-mcp project
- Used for testing file uploads
